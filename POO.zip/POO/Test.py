from Empleado import Empleado

empleado = Empleado(id= None,
                    nombre= None,
                    apellido= None,
                    correo= None,
                    contraseña= None,
                    cargo= None,
                    salario= None,
                    tipo_contrato= None)

empleado.registrar_usuario()
empleado.imprimir_registro()